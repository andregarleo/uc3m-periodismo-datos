# Periodismo de Datos en UC3M

Notas sobre **Periodismo de Datos** en *UC3M*

## Qué es el periodismo de datos
-Periodismo
-Visualización
-Datos

## HTTP
Es una _API_ que tiene cuatro
